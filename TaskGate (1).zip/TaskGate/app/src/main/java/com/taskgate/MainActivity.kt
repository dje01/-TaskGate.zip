package com.taskgate
import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.TimePickerDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var apps: List<Pair<String, String>>   // (nom, package)
    private lateinit var tabs: LinearLayout
    private lateinit var body: LinearLayout
    private var tab = "home"
    private val BG = Color.parseColor("#0F172A"); private val CARD = Color.parseColor("#1E293B")
    private val ACC = Color.parseColor("#22C55E"); private val MUT = Color.parseColor("#94A3B8")
    private val RED = Color.parseColor("#EF4444")
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT; private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        val pm = packageManager
        apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }.distinctBy { it.second }.sortedBy { it.first.lowercase() }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(10), dp(40), dp(10), dp(8)) }
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(tabs) })
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(40)) }
        root.addView(ScrollView(this).apply { addView(body) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 0)
        if (Store.name(this).isBlank()) nameDialog()
    }
    override fun onResume() {
        super.onResume(); render()
        if (hasUsage() && Settings.canDrawOverlays(this)) startForegroundService(Intent(this, MonitorService::class.java))
    }

    // ---------- Helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, r: Int = 16) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }
    private fun tv(t: String, size: Float = 15f, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD) }
    private fun card(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = bg(CARD); setPadding(dp(16), dp(14), dp(16), dp(14))
        v.forEach { addView(it) }
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, dp(6), 0, dp(6)) } }
    private fun button(t: String, color: Int = ACC, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(if (color == ACC) Color.BLACK else Color.WHITE); background = bg(color, 12)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, dp(6), 0, dp(6)) } }
    private fun bar(pct: Int, color: Int = ACC) = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
        max = 100; progress = pct.coerceIn(0, 100)
        progressTintList = ColorStateList.valueOf(color); progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#334155"))
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(10)).apply { setMargins(0, dp(10), 0, 0) } }
    private fun label(pkg: String) = apps.firstOrNull { it.second == pkg }?.first ?: pkg
    private fun hasUsage() = getSystemService(AppOpsManager::class.java)
        .unsafeCheckOpNoThrow("android:get_usage_stats", Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    private fun hm(m: Int) = "%02d:%02d".format(m / 60, m % 60)
    private fun pct(t: Task) = if (t.manual) (if (Store.done(this, t)) 100 else 0) else Store.sec(this, t) * 100 / (t.minutes * 60)
    private fun status(t: Task) = if (Store.done(this, t)) "✅ Fait" else if (t.manual) "À valider" else "${Store.sec(this, t) / 60} / ${t.minutes} min"
    private fun dayName(d: LocalDate) = d.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.FRENCH).replaceFirstChar { it.uppercase() } + " ${d.dayOfMonth}"
    private fun detail(d: LocalDate, ts: List<Task>) = ts.joinToString("  ·  ") { t ->
        t.name + " " + (if (t.manual) (if (Store.done(this, t, d)) "✅" else "❌") else "${Store.sec(this, t, d) / 60}/${t.minutes} min") }

    // ---------- Écrans ----------
    private fun render() {
        val ts = Store.tasks(this)
        if (tab != "home" && tab != "stats" && tab != "set" && ts.none { it.id == tab }) tab = "home"
        tabs.removeAllViews(); body.removeAllViews()
        fun chip(l: String, id: String) = tv(l, 14f, if (tab == id) Color.BLACK else Color.WHITE, true).apply {
            background = bg(if (tab == id) ACC else CARD, 20); setPadding(dp(16), dp(8), dp(16), dp(8))
            layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(4), 0, dp(4), 0) }
            setOnClickListener { tab = id; render() } }
        tabs.addView(chip("🏠 Accueil", "home"))
        ts.forEach { tabs.addView(chip(it.name, it.id)) }
        tabs.addView(tv("➕", 14f, Color.WHITE, true).apply { background = bg(CARD, 20); setPadding(dp(16), dp(8), dp(16), dp(8))
            layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(4), 0, dp(4), 0) }
            setOnClickListener { taskDialog(null) } })
        tabs.addView(chip("📊 Bilan", "stats")); tabs.addView(chip("⚙️", "set"))
        when (tab) { "home" -> home(ts); "stats" -> stats(ts); "set" -> settings(); else -> taskView(ts.first { it.id == tab }) }
    }

    private fun home(ts: List<Task>) {
        body.addView(tv("Bonjour, ${Store.name(this).ifBlank { "toi" }} 👋", 26f, Color.WHITE, true))
        val s = Store.streak(this)
        body.addView(card(tv("🔥 $s jour${if (s > 1) "s" else ""} de suite", 22f, ACC, true), tv("Record : ${Store.best(this)}", 13f, MUT)))
        if (!hasUsage() || !Settings.canDrawOverlays(this))
            body.addView(card(tv("⚠️ Autorisations manquantes : le blocage ne marche pas encore.", 14f, RED), button("Ouvrir les réglages", RED) { tab = "set"; render() }))
        if (ts.isEmpty()) { body.addView(card(tv("Aucune tâche pour l'instant. Touche ➕ en haut pour en créer une : rien n'est bloqué tant qu'il n'y en a pas.", 14f, MUT))); return }
        val done = ts.count { Store.done(this, it) }
        body.addView(card(tv("Aujourd'hui : $done / ${ts.size} tâches", 17f, Color.WHITE, true), bar(done * 100 / ts.size)))
        ts.forEach { t -> body.addView(card(tv(t.name, 17f, Color.WHITE, true), tv(status(t), 13f, MUT), bar(pct(t)))
            .apply { setOnClickListener { tab = t.id; render() } }) }
        body.addView(tv(if (Store.schedOn(this)) "⏰ Blocage actif de ${hm(Store.schedStart(this))} à ${hm(Store.schedEnd(this))}" else "⏰ Blocage actif toute la journée", 13f, MUT))
    }

    private fun taskView(t: Task) {
        val d = Store.done(this, t)
        body.addView(tv(t.name, 26f, Color.WHITE, true))
        body.addView(card(tv(if (t.manual) (if (d) "✅ Validée aujourd'hui" else "À valider quand tu l'as faite")
            else "${Store.sec(this, t) / 60} min / ${t.minutes} min", 20f, if (d) ACC else Color.WHITE, true), bar(pct(t))))
        if (t.manual) body.addView(button(if (d) "Annuler la validation" else "✅ J'ai fini") {
            if (d) { Store.setManual(this, t, false); render() }
            else AlertDialog.Builder(this).setTitle(t.name).setMessage("Tu confirmes l'avoir vraiment fait ?")
                .setPositiveButton("Oui, c'est fait") { _, _ -> Store.setManual(this, t, true); render() }
                .setNegativeButton("Pas encore", null).show() })
        body.addView(card(tv("Apps liées", 13f, MUT), tv(if (t.apps.isEmpty()) "Aucune" else t.apps.joinToString(", ") { label(it) }, 15f)))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 6 downTo 0) { val day = Store.today().minusDays(i.toLong())
            row.addView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                addView(tv(day.dayOfWeek.getDisplayName(TextStyle.NARROW, Locale.FRENCH), 12f, MUT))
                addView(tv(if (Store.done(this@MainActivity, t, day)) "✅" else if (i == 0) "…" else "❌", 18f))
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f) }) }
        body.addView(card(tv("7 derniers jours", 13f, MUT), row))
        body.addView(button("Modifier (nom, minutes, apps)", Color.parseColor("#334155")) { taskDialog(t) })
        body.addView(button("Supprimer cette tâche", RED) {
            AlertDialog.Builder(this).setTitle("Supprimer « ${t.name} » ?").setPositiveButton("Supprimer") { _, _ ->
                Store.saveTasks(this, Store.tasks(this).filter { it.id != t.id }); tab = "home"; render() }
                .setNegativeButton("Annuler", null).show() })
    }

    private fun stats(ts: List<Task>) {
        body.addView(tv("Bilan", 26f, Color.WHITE, true))
        val days = (0..6).map { Store.today().minusDays(it.toLong()) }
        val okDays = days.count { Store.dayOk(this, it) }
        val totalMin = days.sumOf { d -> ts.filter { !it.manual }.sumOf { Store.sec(this, it, d) } } / 60
        body.addView(card(tv("Cette semaine", 13f, MUT), tv("$okDays / 7 jours réussis", 20f, ACC, true),
            tv("$totalMin min en tâches chronométrées  ·  🔥 ${Store.streak(this)} (record ${Store.best(this)})", 13f, MUT)))
        days.forEach { d -> val ok = Store.dayOk(this, d)
            body.addView(card(tv("${dayName(d)}  ${if (ok) "✅" else if (d == Store.today()) "…" else "❌"}", 16f, Color.WHITE, true),
                tv(if (ts.isEmpty()) "Aucune tâche" else detail(d, ts), 13f, MUT))) }
    }

    private fun settings() {
        body.addView(tv("Réglages", 26f, Color.WHITE, true))
        body.addView(button("👤 Mon prénom : ${Store.name(this).ifBlank { "(non défini)" }}", Color.parseColor("#334155")) { nameDialog() })
        body.addView(button("Accès à l'usage ${if (hasUsage()) "✅" else "❌"}", Color.parseColor("#334155")) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        body.addView(button("Affichage par-dessus les apps ${if (Settings.canDrawOverlays(this)) "✅" else "❌"}", Color.parseColor("#334155")) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) })
        body.addView(tv("Que bloquer ?", 17f, Color.WHITE, true).apply { setPadding(0, dp(16), 0, 0) })
        val all = Store.blockAll(this)
        body.addView(button(if (all) "Mode : tout bloquer sauf apps autorisées (changer)" else "Mode : bloquer seulement les apps choisies (changer)", Color.parseColor("#334155")) {
            Store.setBlockAll(this, !all); render() })
        if (all) body.addView(button("Apps toujours autorisées (${Store.allowed(this).size})") {
            pickMany("Apps toujours autorisées", Store.allowed(this)) { Store.setAllowed(this, it); render() } })
        else body.addView(button("Apps à bloquer (${Store.blocked(this).size})") {
            pickMany("Apps à bloquer", Store.blocked(this)) { Store.setBlocked(this, it); render() } })
        body.addView(tv("Horaires", 17f, Color.WHITE, true).apply { setPadding(0, dp(16), 0, 0) })
        val on = Store.schedOn(this); val s = Store.schedStart(this); val e = Store.schedEnd(this)
        body.addView(button(if (on) "⏰ Blocage seulement sur une plage horaire : OUI" else "⏰ Blocage seulement sur une plage horaire : NON", Color.parseColor("#334155")) {
            Store.setSched(this, !on, s, e); render() })
        if (on) {
            body.addView(button("Début du blocage : ${hm(s)}") { TimePickerDialog(this, { _, h, m -> Store.setSched(this, true, h * 60 + m, e); render() }, s / 60, s % 60, true).show() })
            body.addView(button("Fin du blocage : ${hm(e)}") { TimePickerDialog(this, { _, h, m -> Store.setSched(this, true, s, h * 60 + m); render() }, e / 60, e % 60, true).show() })
        }
        body.addView(tv("Téléphone, SMS, accueil et réglages restent toujours accessibles. Les apps des tâches non finies sont débloquées.", 13f, MUT).apply { setPadding(0, dp(16), 0, 0) })
    }

    // ---------- Boîtes de dialogue ----------
    private fun nameDialog() {
        val et = EditText(this).apply { hint = "Ton prénom"; setText(Store.name(this@MainActivity)) }
        AlertDialog.Builder(this).setTitle("Comment t'appelles-tu ?").setView(FrameLayout(this).apply { setPadding(dp(20), dp(10), dp(20), 0); addView(et) })
            .setPositiveButton("OK") { _, _ -> Store.setName(this, et.text.toString().trim()); render() }.show()
    }

    private fun taskDialog(old: Task?) {
        val name = EditText(this).apply { hint = "Nom (ex : Anglais, Sport)"; setText(old?.name ?: "") }
        val min = EditText(this).apply { hint = "Minutes par jour"; inputType = InputType.TYPE_CLASS_NUMBER; setText((old?.minutes ?: 15).toString()) }
        val manual = CheckBox(this).apply { text = "Je valide moi-même (ex : sport sans app)"; isChecked = old?.manual ?: false }
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0)
            addView(name); addView(min); addView(manual) }
        AlertDialog.Builder(this).setTitle(if (old == null) "Nouvelle tâche" else "Modifier la tâche").setView(v)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Suivant") { _, _ ->
                pickMany("Apps liées à cette tâche", old?.apps ?: emptySet()) { sel ->
                    val t = Task(old?.id ?: UUID.randomUUID().toString().take(8), name.text.toString().ifBlank { "Tâche" },
                        (min.text.toString().toIntOrNull() ?: 15).coerceAtLeast(1), sel, manual.isChecked)
                    Store.saveTasks(this, if (old == null) Store.tasks(this) + t else Store.tasks(this).map { if (it.id == old.id) t else it })
                    tab = t.id; render() } }.show()
    }

    private fun pickMany(title: String, current: Set<String>, onOk: (Set<String>) -> Unit) {
        val sel = current.toMutableSet()
        AlertDialog.Builder(this).setTitle(title)
            .setMultiChoiceItems(apps.map { it.first }.toTypedArray(), BooleanArray(apps.size) { apps[it].second in sel }) { _, i, on ->
                if (on) sel.add(apps[i].second) else sel.remove(apps[i].second) }
            .setPositiveButton("OK") { _, _ -> onOk(sel) }.setNegativeButton("Annuler", null).show()
    }
}
