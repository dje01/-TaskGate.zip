package com.taskgate
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime

/** apps = apps qui comptent (tâche chronométrée) ou apps utiles autorisées (tâche manuelle). */
data class Task(val id: String, val name: String, val minutes: Int, val apps: Set<String>, val manual: Boolean)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("tg2", Context.MODE_PRIVATE)
    fun today(): LocalDate = LocalDate.now()

    // ---- Tâches ----
    fun tasks(c: Context): List<Task> {
        val a = JSONArray(p(c).getString("tasks", "[]"))
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i); val j = o.getJSONArray("apps")
            Task(o.getString("id"), o.getString("name"), o.getInt("minutes"),
                (0 until j.length()).map { j.getString(it) }.toSet(), o.getBoolean("manual"))
        }
    }
    fun saveTasks(c: Context, l: List<Task>) {
        val a = JSONArray()
        l.forEach { t -> a.put(JSONObject().put("id", t.id).put("name", t.name).put("minutes", t.minutes)
            .put("apps", JSONArray(t.apps.toList())).put("manual", t.manual)) }
        p(c).edit().putString("tasks", a.toString()).apply()
        updateOk(c)
    }

    // ---- Profil et réglages ----
    fun name(c: Context) = p(c).getString("name", "") ?: ""
    fun setName(c: Context, n: String) = p(c).edit().putString("name", n).apply()
    fun blockAll(c: Context) = p(c).getBoolean("blockAll", true)
    fun setBlockAll(c: Context, v: Boolean) = p(c).edit().putBoolean("blockAll", v).apply()
    fun blocked(c: Context): Set<String> = p(c).getStringSet("blocked", emptySet()) ?: emptySet()
    fun allowed(c: Context): Set<String> = p(c).getStringSet("allowed", emptySet()) ?: emptySet()
    fun setBlocked(c: Context, s: Set<String>) = p(c).edit().putStringSet("blocked", HashSet(s)).apply()
    fun setAllowed(c: Context, s: Set<String>) = p(c).edit().putStringSet("allowed", HashSet(s)).apply()

    // ---- Horaires de blocage (minutes depuis minuit) ----
    fun schedOn(c: Context) = p(c).getBoolean("schedOn", false)
    fun schedStart(c: Context) = p(c).getInt("schedStart", 8 * 60)
    fun schedEnd(c: Context) = p(c).getInt("schedEnd", 22 * 60)
    fun setSched(c: Context, on: Boolean, s: Int, e: Int) =
        p(c).edit().putBoolean("schedOn", on).putInt("schedStart", s).putInt("schedEnd", e).apply()
    fun inWindow(c: Context): Boolean {
        if (!schedOn(c)) return true
        val n = LocalTime.now(); val m = n.hour * 60 + n.minute; val s = schedStart(c); val e = schedEnd(c)
        return if (s <= e) m in s until e else (m >= s || m < e)
    }

    // ---- Progression (conservée par jour pour le bilan) ----
    fun sec(c: Context, t: Task, d: LocalDate = today()) = p(c).getInt("sec_${d}_${t.id}", 0)
    fun addSec(c: Context, t: Task, n: Int) {
        val old = sec(c, t); val nv = old + n
        p(c).edit().putInt("sec_${today()}_${t.id}", nv).apply()
        if (old < t.minutes * 60 && nv >= t.minutes * 60) updateOk(c)
    }
    fun setManual(c: Context, t: Task, v: Boolean) {
        p(c).edit().putBoolean("man_${today()}_${t.id}", v).apply(); updateOk(c)
    }
    fun done(c: Context, t: Task, d: LocalDate = today()) =
        if (t.manual) p(c).getBoolean("man_${d}_${t.id}", false) else sec(c, t, d) >= t.minutes * 60
    fun allDone(c: Context) = tasks(c).all { done(c, it) }

    // ---- Série de jours réussis ----
    fun dayOk(c: Context, d: LocalDate) = p(c).getBoolean("ok_$d", false)
    fun best(c: Context) = p(c).getInt("best", 0)
    fun updateOk(c: Context) {
        val ts = tasks(c); if (ts.isEmpty()) return
        p(c).edit().putBoolean("ok_${today()}", ts.all { done(c, it) }).apply()
        val s = streak(c); if (s > best(c)) p(c).edit().putInt("best", s).apply()
    }
    fun streak(c: Context): Int {
        var d = today(); if (!dayOk(c, d)) d = d.minusDays(1)
        var n = 0
        while (dayOk(c, d) && n < 1000) { n++; d = d.minusDays(1) }
        return n
    }
}
