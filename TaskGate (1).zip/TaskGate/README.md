# TaskGate v3 (Android)
Onglet par tâche, accueil personnalisé, série de jours (streak), bilan semaine/jour, horaires de blocage, thème sombre.
